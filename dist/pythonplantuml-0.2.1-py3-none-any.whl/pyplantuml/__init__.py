# plantuml_generator/__init__.py
from .core import plantuml, generate_uml_png
